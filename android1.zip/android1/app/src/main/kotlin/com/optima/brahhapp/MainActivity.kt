package com.optima.brahhapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
